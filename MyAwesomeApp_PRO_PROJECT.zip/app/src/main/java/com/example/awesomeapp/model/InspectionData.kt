package com.example.awesomeapp.model

data class InspectionData(
    var id: String = "",
    var assetName: String = "",
    var assetLocation: String = "",
    var inspectorName: String = "",
    var description: String = "",
    var hasPhoto: Boolean = false,
    var isSigned: Boolean = false
)