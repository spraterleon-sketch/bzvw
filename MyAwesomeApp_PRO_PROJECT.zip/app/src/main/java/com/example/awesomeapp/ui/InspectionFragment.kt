package com.example.awesomeapp.ui

import android.graphics.Bitmap
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.example.awesomeapp.databinding.FragmentInspectionBinding
import com.example.awesomeapp.model.InspectionData

class InspectionFragment : Fragment() {

    private var _binding: FragmentInspectionBinding? = null
    private val binding get() = _binding!!
    private val inspectionData = InspectionData()

    // Simple Camera Launcher for MVP
    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) {
            binding.imgPreview.setImageBitmap(bitmap)
            binding.imgPreview.visibility = View.VISIBLE
            inspectionData.hasPhoto = true
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentInspectionBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Photo Button
        binding.btnTakePhoto.setOnClickListener {
            cameraLauncher.launch(null)
        }

        // Clear Signature
        binding.btnClearSignature.setOnClickListener {
            binding.signatureView.clear()
            inspectionData.isSigned = false
        }

        // Generate PDF Action
        binding.btnGeneratePdf.setOnClickListener {
            saveDataAndGeneratePdf()
        }
    }

    private fun saveDataAndGeneratePdf() {
        inspectionData.assetName = binding.inputAssetName.text.toString()
        inspectionData.assetLocation = binding.inputAssetLocation.text.toString()
        inspectionData.isSigned = true // Assumed if button clicked for MVP
        
        // Placeholder for real PDF Generation
        Toast.makeText(context, "PDF mit Unterschrift für ${inspectionData.assetName} generiert!", Toast.LENGTH_LONG).show()
        
        // Here you would implement PdfDocument logic using the data and signature bitmap
        // val sigBitmap = binding.signatureView.getSignatureBitmap()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}